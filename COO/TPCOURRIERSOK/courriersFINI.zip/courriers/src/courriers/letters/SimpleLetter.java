package courriers.letters;

import courriers.city.InHabitants;
import courriers.content.TextContent;

public class SimpleLetter<T extends TextContent> extends Letter<T>{
	
	protected final int cost;
	
    /**
     * Create a simple letter with a sender, a receiver and a text
     * @param sender
     * @param receiver
     * @param text
     */
	public SimpleLetter(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver, content);
		this.cost = 1;	
	}
	/**
	 * the action who happened when you send a simple letter
	 */
	@Override
	public void toDo() {		
		sender.debit(this.getCost());
	}

	/**
	 * @return the description of a simple letter
	 */
	@Override
	public String toString() {
		return "a simple letter";
	}
	/**
	 * Return cost of the letter
	 * @return cost of the letter
	 */
	public int getCost() {
		return cost;
	}
	
	/**
	 * Return the content of the letter
	 * @return the content of the letter
	 */
	public T getContent(){
		return this.content;
	}
}
