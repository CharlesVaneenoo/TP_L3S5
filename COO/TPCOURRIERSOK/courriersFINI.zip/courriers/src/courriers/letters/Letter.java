package courriers.letters;

import courriers.city.InHabitants;

public abstract class Letter<T>{
	
	protected InHabitants sender;
	protected InHabitants receiver;
	protected T content;
	protected int cost;
	
	/**
	 * Create a letter with a sender and a receiver
	 * @param sender
	 * @param receiver
	 * @param content
	 */
	public Letter(InHabitants sender, InHabitants receiver, T content){
		this.sender = sender;
		this.receiver = receiver;
		this.content = content;
	}
	
	/**
	 * abstract method toString
	 */
	public abstract String toString();
	
	/**
	 * abstract method toDo
	 */
	public abstract void toDo();
	
	/**
	 * abstract method getCost
	 */
	public abstract int getCost();
	
	/**
	 * Return the inhabitant who sent the letter
	 * @return the inhabitant who sent the letter
	 */
	public InHabitants getSender() {
		return this.sender;
	}
	
	/**
	 * Return the inhabitant who receive the letter
	 * @return the inhabitant who receive the letter
	 */
	public InHabitants getReceiver() {
		return this.receiver;
	}
	
	/** 
	 * Return the content
	 * @return the content
	 */
	public T getContent() {
		return content;
	}
}
