package courriers.letters;

import courriers.city.InHabitants;

public class UrgentLetter<T extends Letter<?>> extends LetterDecorator<T> {
	
	public UrgentLetter(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver, content);
	}

	/**
	 * Return the description of an urgent letter
	 * @return the description of an urgent letter
	 */
	@Override
	public String toString() {
		return "an urgent letter";
	}

	/**
	 * Do the action who happened when you send a urgent letter
	 */
	@Override
	public void toDo() {
		//this.content.toDo();
		this.getSender().debit(getCost());
	}

	/**
	 * Return the cost of an urgent letter
	 * @return the cost of an urgent letter
	 */
	@Override
	public int getCost() {
		return this.content.getCost()*2;
	}

}
