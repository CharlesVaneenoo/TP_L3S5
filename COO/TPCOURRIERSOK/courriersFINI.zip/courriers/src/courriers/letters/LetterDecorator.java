package courriers.letters;

import courriers.city.InHabitants;

public abstract class LetterDecorator<T extends Letter<?>> extends Letter<T>{

	public LetterDecorator(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver, content);
	}	
}
