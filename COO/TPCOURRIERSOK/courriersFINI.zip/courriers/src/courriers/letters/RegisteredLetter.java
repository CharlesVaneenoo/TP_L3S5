package courriers.letters;

import courriers.city.InHabitants;

public class RegisteredLetter<T extends Letter<?>> extends LetterDecorator<T>{
	
	/**
	 * Create a registered letter with a sender, a receiver and a content
	 * @param sender
	 * @param receiver
	 * @param content
	 */	
	public RegisteredLetter(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver,content);
	}

	/**
	 * Do the action who happened when you send a registered letter
	 */
	@Override
	public void toDo() {
		this.content.toDo();
	}

	/**
	 * Return the description of a registered letter
	 * @return the description of a registered letter
	 */
	@Override
	public String toString() {
		return "a registered letter";
	}
	/**
	 * Return the cost of a registered letter
	 * @return the cost of a registered letter
	 */
	@Override
	public int getCost() {
		return content.getCost() + 15;
	}

}
