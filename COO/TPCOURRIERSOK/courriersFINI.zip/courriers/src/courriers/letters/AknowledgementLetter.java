package courriers.letters;

import courriers.city.InHabitants;
import courriers.content.TextContent;

public class AknowledgementLetter<T extends TextContent> extends Letter<T> {

	public AknowledgementLetter(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver, content);
	}
	
	/**
	 * Return the description of an aknowledgement letter
	 * @return the description of an aknowledgement letter
	 */
	@Override
	public String toString() {
		return "an aknowledgement of receipt";
	}

	
	/**
	 * Return the cost of an aknowledgement letter
	 * @return the cost of an aknowledgement letter 
	 */
	@Override
	public int getCost() {
		return 0;
	}

	/**
	 * Nothing to do.
	 */
	@Override
	public void toDo() {}



}
