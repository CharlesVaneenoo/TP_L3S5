package courriers.letters;

import courriers.city.InHabitants;
import courriers.content.TextContent;

public class ThanksLetter<T extends TextContent> extends Letter<T> {

	public ThanksLetter(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver, content);
	}
	
	/**
	 * Return the description of a thanks letter
	 * @return the description of a thanks letter
	 */
	@Override
	public String toString() {
		return "an thank's letter";
	}
	
	/**
	 * Return the cost of a thanks letter
	 * @return the cost of a thanks letter 
	 */
	@Override
	public int getCost() {
		return 0;
	}

	/**
	 * Nothing to do.
	 */
	@Override
	public void toDo() {}

}
