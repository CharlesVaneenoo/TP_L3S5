package courriers.letters;

import courriers.city.InHabitants;
import courriers.content.MoneyContent;

public class PromisoryNote<T extends MoneyContent> extends Letter<T>{
	
	private int amount;
	private int cost=1;

	/**
	 * Create a promisory note with a sender, a receiver and a content 
	 * @param sender
	 * @param receiver
	 * @param content
	 */
	public PromisoryNote(InHabitants sender, InHabitants receiver, T content) {
		super(sender, receiver, content);
		this.amount = content.getAmount();
	}

	/**
	 * The action which happened when you send a promisory note
	 */
	@Override
	public void toDo(){
		sender.debit(amount+cost);
		receiver.credit(amount);
	}
	
	/**
	 * Return the description of a PromisoryNote
	 * @return the description of a PromisoryNote
	 */
	@Override
	public String toString() {
		return "a promisory note";
	}

	/**
	 * Return the cost of a PromisoryNote
	 * @return the cost of a PromisoryNote
	 */
	@Override
	public int getCost() {
		return 1 + (content.getAmount()/100);		
	}
}
