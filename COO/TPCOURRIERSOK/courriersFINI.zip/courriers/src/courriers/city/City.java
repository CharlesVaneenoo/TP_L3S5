package courriers.city;

import java.util.*;

import courriers.content.TextContent;
import courriers.letters.*;

public class City {
	
 	protected String name;
	protected List<Letter<?>> postbox;
	protected List<Letter<?>> stockbox;
	protected List<InHabitants> inHabitantsList;

	/**
	 * Constructor of the class City
	 * @param name = the name of the city
	 */
	public City(String name){
		this.name = name;
		this.postbox = new ArrayList<Letter<?>>(); 
		this.stockbox = new ArrayList<Letter<?>>(); 
		this.inHabitantsList = new ArrayList<InHabitants>(); 
	}
	
	/**
	 * Add a letter in the postbox
	 * @param letters
	 */
	public void sendLetters(Letter<?> letters){
		stockbox.add(letters);
	}
	
	/**
	 * Distribute all the letters in the postbox
	 */
	public void distributeLetters(){
		if (postbox.isEmpty()){
			System.out.println("The postbox is empty today");
		}
		for(Letter<?> l : postbox){
			l.getReceiver().receiveLetter(l);
			// if we have a registred letter then we send an aknowledgement letter
			if (l.toString() == "a registered letter"){
				TextContent msg = new TextContent("an aknowledgement letter ..........");
				AknowledgementLetter<TextContent> aknowledgement = new  AknowledgementLetter<TextContent>(l.getReceiver(), l.getSender(), msg);
				stockbox.add(aknowledgement);
			}
			if (l.toString() == "a promisory note"){
				TextContent msg = new TextContent("a thank's letter ..........");
				ThanksLetter<TextContent> thanks = new  ThanksLetter<TextContent>(l.getReceiver(), l.getSender(), msg);
				stockbox.add(thanks);
			}
		}
		postbox.clear();
	}
	
	/**
	 * add the letter of the stockbox in the postbox
	 */
	public void gatherLetters(){
		for(Letter<?> l : stockbox){
			this.postbox.add(l);
		}
		stockbox.clear();
	}

	/**
	 * Return the name of the city
	 * @return the name of the city
	 */
	public String getName() {
		return name;
	}

	/**
	 * Return the postbox of the city
	 * @return the postbox of the city
	 */
	public List<Letter<?>> getPostbox() {
		return postbox;
	}

	/**
	 * Return the stockbox of the city
	 * @return the stockbox of the city
	 */
	public List<Letter<?>> getStockbox() {
		return stockbox;
	}

	/**
	 * Return the list of inhabitants of the city
	 * @return the list of inHabitantsList of the city 
	 */
	public List<InHabitants> getInHabitantsList() {
		return inHabitantsList;
	}
}
