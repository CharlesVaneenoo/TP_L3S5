package courriers.city;

import courriers.letters.Letter;

public class InHabitants{

	private String name;
	private int bankAccount;
	private City city;
		
	public InHabitants(String name, int bankAccount, City city) {
			this.name=name;
			this.bankAccount=bankAccount;
			this.city=city;
	}

	/**
	 * Return the amount on the bankAccount of the Inhabitant
	 * @return the amount on the bankAccount of the Inhabitant
	 */
	public int getAccount(){
		return this.bankAccount;
	}
	
	/**
	 * Credit the amount on to the inhabitant bankAccount 
	 * @param the amount to credit to the inhabitant bankAccount
	 */
	public void credit(int amount){
		this.bankAccount += amount;
		System.out.println("	+ " + amount + " euros are credited from " + this.getName()+ " account whose balance is now " + this.getAccount() + " euro(s)");
	}
	
	/**
	 * Debit the amount on to the inhabitant bankAccount 
	 * @param the amount to credit to the inhabitant bankAccount
	 */
	public void debit(int amount){
		if (this.bankAccount <= 0){
			System.out.println("	- You can't buy anything");
		}
		else {
			this.bankAccount -= amount;
			System.out.println("	- " +amount + " euros are debited from " + this.getName()+ " account whose balance is now " + this.getAccount() + " euro(s)");
		}
	}
	
	/**
	 * Return the city of the inhabitant  
	 * @return the city of the inhabitant 
	 */
	public City getCity(){
		return this.city;
	}
	
	/**
	 * Return the name of the inhabitant
	 * @return the name of the inhabitant
	 */
	public String getName(){
		return this.name;
	}
	
	/**
	 * the action who happened when you send a letter 
	 * @param l a letter
	 */
	public void sendLetter(Letter<?> l){
		this.getCity().sendLetters(l);
		System.out.println("-> " + this.getName()+" mails "+l.toString()+" whose content is "+ l.getContent() +" to "+l.getReceiver().getName()+" for a cost of "+l.getCost()+" euro(s)");
		this.debit(l.getCost());
	}
	
	/**
	 * the action who happened when you receive a letter
	 * @param l a letter
	 */
	public void receiveLetter(Letter<?> l){
		System.out.println("<- " + l.getReceiver().getName() + " receives " + l.toString() + " whose content is " + l.getContent().toString() + " from " + l.getSender().getName());
		l.toDo();
	}

}
