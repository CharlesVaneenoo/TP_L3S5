package courriers.content;

public class TextContent implements Content{
	
	private String text;
	
	/**
	 * Constructor of the text content
	 * @param text
	 */
	public TextContent(String text){
		this.text = text;
	}

	/**
	 * Return the description of the text content
	 * @return the description of the text content
	 */
	public String description() {
		return "a text content";
	}

	/**
	 * Return the text used
	 * @return the text
	 */
	public String getText() {
		return text;
	}
	
	/**
	 * Return "a text content"
	 * @return "a text content"
	 */
	public String toString() {
		return "a text content";
	}
}
