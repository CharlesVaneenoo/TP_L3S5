package courriers.content;

public class MoneyContent implements Content{
	
	private int amount;
	
	/**
	 * Create a money content with a amount
	 * @param amount
	 */
	public MoneyContent(int amount){
		this.amount = amount;
	}
	
	/**
	 * Return the amount of the money content
	 * @return the amount of a money content 
	 */
	public int getAmount(){
		return this.amount;
	}
	
	/**
	 * Return a description of a money content
	 * @return a description of a money content
	 */
	@Override
	public String description() {
		return "a money content";
	}

	public String toString() {
		return "a money content";
	}
}
