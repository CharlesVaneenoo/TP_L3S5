package courriers.content;

public interface Content {
	public String description();
}
