package courriers;

import java.util.*;
import courriers.city.*;
import courriers.content.*;
import courriers.letters.*;

public class Main {
	private static Scanner sc;
	protected Random r;
	protected City city;
	
	public Main(){
		// creation of the City
		city = new City("Lille");
		this.r = new Random();

		sc = new Scanner(System.in);

		// fill the List of InHabitants InHabitantsListLille with k inhabitants
		int k = 100;
		for (int i = 1; i<=k; i++ ){
		    int random = (int)(Math.random() * (100));
				InHabitants inhabitant = new InHabitants("inhabitant-"+i,random,this.city);
				city.getInHabitantsList().add(inhabitant);
		}
	}
	// creation of a random letter
	public Letter<?> createRandomsLetters(InHabitants sender, InHabitants receiver){
		Letter<?> letter;

		Letter<TextContent> lettre = new SimpleLetter<TextContent>(sender, receiver, new TextContent("Test envoi SIMPLE LETTER")) ;
			switch (r.nextInt(4)) {
				case 0:
						letter = new PromisoryNote<MoneyContent>(sender, receiver, new MoneyContent(10)) ;
				break;
				case 1:
						letter = new SimpleLetter<TextContent>(sender, receiver, new TextContent("Test envoi SIMPLE LETTER")) ;
				break ;
				case 2:
						letter = new UrgentLetter<Letter<TextContent>>(sender, receiver, lettre);
				break ;
				default:
						letter = new RegisteredLetter<Letter<TextContent>>(sender, receiver, lettre);
				break ;
			}	
		return letter;
}
	
	public static void main(String [] args){
		// creation of the City
		Main main = new Main();
		// Boxes cleaning
		main.city.getPostbox().clear();
		main.city.getStockbox().clear();
		int nbDay = 1;
		
		//Scan how much days the user choose
		sc = new Scanner(System.in);
		System.out.println("Please type how much day(s) you want : ");
		int nb = sc.nextInt();
		
		// Display information for the user
		System.out.println("Creating Lille City");
		System.out.println("Creating 100 inhabitants.");
		System.out.println("Mailing letters for "+nb+" days");
			for (int i=1; i<=nb; i++){
				System.out.println("+++++++++++++++++++++++++++++++++++");				
				System.out.println("Day "+i);
				System.out.println("+++++++++++++++++++++++++++++++++++");				
				if (!main.city.getPostbox().isEmpty()){
					System.out.println("			***********************************");
					System.out.println("				Distributing letters");
					System.out.println("			***********************************");
					main.city.distributeLetters();
				}
				System.out.println("			***********************************");
				System.out.println("				Sending letters");
				System.out.println("			***********************************");
				
				int nbMailsToSend = main.r.nextInt(10);
				
					for (int j = 0 ; j <= nbMailsToSend; j++){
						int r1 = main.r.nextInt(100);
						int r2 = main.r.nextInt(100);
					
						
						main.city.getInHabitantsList().get(r1).sendLetter(main.createRandomsLetters(main.city.getInHabitantsList().get(r1),main.city.getInHabitantsList().get(r2)));
					}
// Gathering letters in the stockbox
				main.city.gatherLetters();				
			}
			while(!main.city.getPostbox().isEmpty()){
				System.out.println("+++++++++++++++++++++++++++++++++++");				
				System.out.println("Day "+(nb+nbDay));
				System.out.println("+++++++++++++++++++++++++++++++++++");	
				System.out.println("			***********************************");
				System.out.println("				Distributing letters");
				System.out.println("			***********************************");
				main.city.distributeLetters();
				nbDay++;
			}
		
	}
}
