package courriers.city;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.content.TextContent;
import courriers.letters.SimpleLetter;

public class InHabitantsTest {
	
	
	public InHabitants create() { 
		City city = new City("Villeneuve d'Ascq");
		return new InHabitants("Carlito",111,city);
	}
	
	@Test
	public void TestHabitantName(){
		InHabitants inhabitant = this.create();
		assertEquals(inhabitant.getName(),"Carlito");
	}
	@Test
	public void TestHabitantCityName(){
		InHabitants inhabitant = this.create();
		assertEquals(inhabitant.getCity().getName(),"Villeneuve d'Ascq");
	}
	@Test
	public void TestHabitantBankAccount(){
		InHabitants inhabitant = this.create();
		assertEquals(inhabitant.getAccount(),111);
	}
	
	@Test
	public void TestHabitantCreditandDebit(){
		InHabitants inhabitant = this.create();
		assertEquals(inhabitant.getAccount(),111);
		inhabitant.debit(20);
		assertEquals(inhabitant.getAccount(),91);
		inhabitant.credit(20);
		assertEquals(inhabitant.getAccount(),111);
	}
	
	@Test 
	public void TestHabitantDebitWithoutMoney(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants inhabitant = new InHabitants("GimmeMoneyPLZ",0,city);
		
		assertEquals(inhabitant.getAccount(),0);
		inhabitant.debit(28829910);

	}
	
	@Test
	public void TestSendLetter(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants inhabitant1 = new InHabitants("hab1",100,city);
		InHabitants inhabitant2 = new InHabitants("hab2",100,city);
		city.getInHabitantsList().add(inhabitant1);
		city.getInHabitantsList().add(inhabitant2);
		SimpleLetter<TextContent> letter1 = new SimpleLetter<TextContent>(inhabitant1, inhabitant2, new TextContent("Test envoie lettre"));
		assertEquals(inhabitant1.getAccount(),100);
		assertEquals(inhabitant2.getAccount(),100);
		inhabitant1.sendLetter(letter1);
		assertEquals(inhabitant2,letter1.getReceiver());
		assertEquals(inhabitant1.getAccount(),99);
		assertEquals(inhabitant2.getAccount(),100);
	}
	
}
  
