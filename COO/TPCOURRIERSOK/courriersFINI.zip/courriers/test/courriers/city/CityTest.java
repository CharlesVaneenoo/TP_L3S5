package courriers.city;

import static org.junit.Assert.*;

import courriers.content.*;
import courriers.letters.*;

import org.junit.Test;

public class CityTest {

	
	public City create() {
		return new City("Lille");	
	}
	
	@Test
	public void TestCityList(){
	City Lille = this.create();
	InHabitants inhabitant1 = new InHabitants("inhabitant1",100,Lille);
	Lille.getInHabitantsList().add(inhabitant1);
	assertTrue(Lille.getInHabitantsList().contains(inhabitant1));
	assertEquals(Lille.getInHabitantsList().size(),1);
	}
	
	@Test
	public void getCityName(){
		City Lille = this.create();
		assertEquals(Lille.getName(),"Lille");
	}
	
	@Test
	public void sendLettersTest(){
		City city = this.create();
		InHabitants inhabitant1 = new InHabitants("inhabitant1",100,city);
		InHabitants inhabitant2 = new InHabitants("inhabitant2",10,city);
		Letter<TextContent> l = new SimpleLetter<TextContent>(inhabitant1, inhabitant2, new TextContent("Test envoie lettre simple"));
		city.sendLetters(l);
		assertEquals(city.getStockbox().size(),1);
		assertEquals(city.getPostbox().size(),0);
		city.gatherLetters();
		assertEquals(city.getPostbox().size(),1);
		assertEquals(city.getStockbox().size(),0);
		city.distributeLetters();
		assertEquals(city.getPostbox().size(),0);
	}
	
	@Test
	public void distributeLettersAndgatherLettersTest(){
		City city = this.create();
		InHabitants inhabitant1 = new InHabitants("inhabitant1",100,city);
		InHabitants inhabitant2 = new InHabitants("inhabitant2",10,city);
		Letter<?> l;
		Letter<TextContent> sl1 = new SimpleLetter<TextContent>(inhabitant1, inhabitant2, new TextContent("Test envoie lettre simple 1 "));
		Letter<TextContent> sl2 = new SimpleLetter<TextContent>(inhabitant1, inhabitant2, new TextContent("Test envoie lettre simple 2"));
		l = new RegisteredLetter<Letter<TextContent>>(inhabitant2, inhabitant1, sl1);
		PromisoryNote<MoneyContent> l2 = new PromisoryNote<MoneyContent>(inhabitant2, inhabitant1, new MoneyContent(10));
		city.sendLetters(l);
		city.sendLetters(sl2);

		assertEquals(city.getPostbox().size(),0);
		city.gatherLetters();	
		assertEquals(city.getPostbox().size(),2);

		
		System.out.println("Day 1 : distribute letters");
		city.distributeLetters();	
		System.out.println("Day 2 : distribute letters");
		city.gatherLetters();
		city.distributeLetters();	
		System.out.println("Day 3 : distribute letters");
		city.distributeLetters();	
		//test promisory note
		city.sendLetters(l2);
		assertEquals(city.getPostbox().size(),0);
		city.gatherLetters();	
		assertEquals(city.getPostbox().size(),1);
		city.distributeLetters();	


	}
	
}
