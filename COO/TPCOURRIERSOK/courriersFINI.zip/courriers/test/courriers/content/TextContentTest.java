package courriers.content;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.content.TextContent;

public class TextContentTest {


	public TextContent create(){
		TextContent text =  new TextContent("abc");
		return text;
	}
	
	@Test 
	public void GetAmountTest(){
		TextContent text = this.create();
		assertEquals("abc", text.getText());
	}
	
	@Test 
	public void getdescription(){
		TextContent text = this.create();
		assertEquals("a text content", text.description());
	}
	
	@Test 
	public void ToStringTest(){
		TextContent text = this.create();
		assertEquals("a text content", text.toString());
	}

}
