package courriers.content;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.content.MoneyContent;

public class MoneyContentTest {

	
	public MoneyContent create(){
		MoneyContent money =  new MoneyContent(10);
		return money;
	}
	
	@Test 
	public void GetAmountTest(){
		MoneyContent money = this.create();
		assertEquals(10, money.getAmount());
	}
	
	@Test 
	public void DescriptionTest(){
		MoneyContent money = this.create();
		assertEquals("a money content", money.description());
	}
	
	@Test 
	public void ToStringTest(){
		MoneyContent money = this.create();
		assertEquals("a money content", money.toString());
	}
}
