package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.TextContent;



public class AknowledgementLetterTest {

	public AknowledgementLetter<TextContent> create(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Carlito1",1111,city);
		AknowledgementLetter<TextContent> letter1 = new AknowledgementLetter<TextContent>(num1, num2, new TextContent("Test envoie lettre"));
		return letter1;
	}

	@Test
	public void TestPrice(){
		AknowledgementLetter<TextContent> letter = this.create();
		assertEquals(0,letter.getCost());
	}
	

	@Test
	public void TestToSring(){
		AknowledgementLetter<TextContent> letter = this.create();
		assertEquals("an aknowledgement of receipt",letter.toString());
	}
}
