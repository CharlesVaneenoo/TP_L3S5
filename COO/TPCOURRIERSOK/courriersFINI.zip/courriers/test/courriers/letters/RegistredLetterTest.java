package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.TextContent;

public class RegistredLetterTest {
	
	public RegisteredLetter<Letter<TextContent>> create(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Carlito1",1111,city);
		Letter<TextContent> lettersimple = new SimpleLetter<TextContent>(num1, num2, new TextContent("Test envoi SIMPLE LETTER")) ;
		RegisteredLetter<Letter<TextContent>> letter1 = new RegisteredLetter<Letter<TextContent>>(num1, num2,lettersimple );
		return letter1;
	}

	@Test
	public void TestPrice(){
		RegisteredLetter<Letter<TextContent>> letter = this.create();
		assertEquals(16,letter.getCost());
	}

	@Test
	public void TestToSring(){
		RegisteredLetter<Letter<TextContent>> letter = this.create();
		assertEquals("a registered letter",letter.toString());
	}

	@Test
	public void TestContent(){
		RegisteredLetter<Letter<TextContent>> letter = this.create();
		assertEquals("Test envoi SIMPLE LETTER",letter.getContent().getContent().getText());
	}
	
	@Test
	public void TestToDo(){
		RegisteredLetter<Letter<TextContent>> letter = this.create();
		assertEquals(letter.sender.getAccount(),111);
		letter.sender.debit(letter.getCost());
		assertEquals(letter.sender.getAccount(),95);
	}

}
