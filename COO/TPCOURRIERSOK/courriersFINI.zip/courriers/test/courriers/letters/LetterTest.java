package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.MoneyContent;
import courriers.content.TextContent;

public class LetterTest {

	@Test
	public void costNotNull(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Kevinito",1111,city);

		Letter<TextContent> lettersimple = new SimpleLetter<TextContent>(num1, num2, new TextContent("Test envoi SIMPLE LETTER")) ;
		
		AknowledgementLetter<TextContent> l1 = new AknowledgementLetter<TextContent>(num1, num2, new TextContent("Test envoie lettre"));
		PromisoryNote<MoneyContent> l2 = new PromisoryNote<MoneyContent>(num1, num2, new MoneyContent(10)) ;
		RegisteredLetter<Letter<TextContent>> l3 = new RegisteredLetter<Letter<TextContent>>(num1, num2,lettersimple );
		SimpleLetter<TextContent> l4 = new SimpleLetter<TextContent>(num1, num2, new TextContent("Test envoie lettre"));
		UrgentLetter<Letter<TextContent>> l5 = new UrgentLetter<Letter<TextContent>>(num1, num2, lettersimple);
		
		assertNotNull(l1.getCost());
		assertNotNull(l2.getCost());
		assertNotNull(l3.getCost());
		assertNotNull(l4.getCost());
		assertNotNull(l5.getCost());
	}

	@Test
	public void contentTextAtCompilation(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Kevinito",1111,city);

		SimpleLetter<TextContent> l4 = new SimpleLetter<TextContent>(num1, num2, new TextContent("Test envoie lettre"));
		assertEquals(l4.getContent().description(),"a text content");
		
	}
}
