package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.TextContent;

public class ThanksLetterTest {

	public ThanksLetter<TextContent> create(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Carlito1",1111,city);
		ThanksLetter<TextContent> letter1 = new  ThanksLetter<TextContent>(num1, num2, new TextContent("Test envoie lettre"));
		return letter1;
	}

	@Test
	public void TestPrice(){
		 ThanksLetter<TextContent> letter = this.create();
		assertEquals(0,letter.getCost());
	}
	

	@Test
	public void TestToSring(){
		 ThanksLetter<TextContent> letter = this.create();
		assertEquals("an thank's letter",letter.toString());
	}
}
