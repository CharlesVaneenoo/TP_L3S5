package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.TextContent;

public class UrgentLetterTest {

	public UrgentLetter<Letter<TextContent>> create(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Carlito1",1111,city);
		Letter<TextContent> lettersimple = new SimpleLetter<TextContent>(num1, num2, new TextContent("Test envoi SIMPLE LETTER")) ;
		UrgentLetter<Letter<TextContent>> letter1 = new UrgentLetter<Letter<TextContent>>(num1, num2, lettersimple);

		return letter1;
	}

	@Test
	public void TestPrice(){
		UrgentLetter<Letter<TextContent>> letter = this.create();
		assertEquals(2,letter.getCost());
	}

	@Test
	public void TestToSring(){
		UrgentLetter<Letter<TextContent>> letter = this.create();
		assertEquals("an urgent letter",letter.toString());
	}

	@Test
	public void TestContent(){
		UrgentLetter<Letter<TextContent>> letter = this.create();
		assertEquals("Test envoi SIMPLE LETTER",letter.getContent().getContent().getText());
	}
	
	@Test
	public void TestToDo(){
		UrgentLetter<Letter<TextContent>> letter = this.create();
		assertEquals(letter.sender.getAccount(),111);
		letter.toDo();
		assertEquals(letter.sender.getAccount(),109);

	}

}
