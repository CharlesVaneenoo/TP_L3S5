package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.TextContent;

public class SimpleLetterTest {

	public SimpleLetter<TextContent> create(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Carlito1",1111,city);
		SimpleLetter<TextContent> letter1 = new SimpleLetter<TextContent>(num1, num2, new TextContent("Test envoie lettre"));
		return letter1;
	}

	@Test
	public void TestPrice(){
		SimpleLetter<TextContent> letter = this.create();
		assertEquals(1,letter.getCost());
	}

	@Test
	public void TestToSring(){
		SimpleLetter<TextContent> letter = this.create();
		assertEquals("a simple letter",letter.toString());
	}

	@Test
	public void TestContent(){
		SimpleLetter<TextContent> letter = this.create();
		assertEquals("Test envoie lettre",letter.getContent().getText());
	}
	
	@Test
	public void TestToDo(){
		SimpleLetter<TextContent> letter = this.create();
		assertEquals(letter.sender.getAccount(),111);
		letter.sender.debit(letter.getCost());
		assertEquals(letter.sender.getAccount(),110);

	}
}
