package courriers.letters;

import static org.junit.Assert.*;

import org.junit.Test;

import courriers.city.City;
import courriers.city.InHabitants;
import courriers.content.MoneyContent;


public class PromisoryNoteTest {

	public PromisoryNote<MoneyContent> create(){
		City city = new City("Villeneuve d'Ascq");
		InHabitants num1 = new InHabitants("Carlito",111,city);
		InHabitants num2 = new InHabitants("Carlito1",1111,city);
		PromisoryNote<MoneyContent> letter1 = new PromisoryNote<MoneyContent>(num1, num2, new MoneyContent(10)) ;
		return letter1;
	}

	@Test
	public void TestPrice(){
		PromisoryNote<MoneyContent> letter = this.create();
		assertEquals(1,letter.getCost());
	}

	@Test
	public void TestToSring(){
		PromisoryNote<MoneyContent> letter = this.create();
		assertEquals("a promisory note",letter.toString());
	}

	@Test
	public void TestContent(){
		PromisoryNote<MoneyContent> letter = this.create();
		assertEquals(10,letter.getContent().getAmount());
	}
	
	@Test
	public void TestToDo(){
		PromisoryNote<MoneyContent> letter = this.create();
		assertEquals(letter.sender.getAccount(),111);
		assertEquals(letter.receiver.getAccount(),1111);
		letter.toDo();
		assertEquals(letter.sender.getAccount(),100);
		assertEquals(letter.receiver.getAccount(),1121);

	}

}
