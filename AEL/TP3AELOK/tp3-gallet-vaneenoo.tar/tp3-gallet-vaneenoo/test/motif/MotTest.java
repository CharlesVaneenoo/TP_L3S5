package motif;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MotTest {

	protected Mot mot1;
	protected Mot mot2;
	protected Mot mot3;
	protected Mot motvide;
	protected Mot mot4;

	@Before
	public void createMots(){
		mot1 = new Mot("Chocolat");
		mot2 = new Mot("cola");
		mot3 = new Mot("ababaca");
		motvide = new Mot("");
		mot4 = new Mot("aba");
	}

	@Test
	public void algoNaifTest() {
		/* Cas ou on ne trouve pas le mot */
		assertEquals(-1,mot1.indiceMotifNaif(mot4));
		/* Cas normal */
		assertEquals(3,mot1.indiceMotifNaif(mot2));
	}

	@Test
	public void algoAutomateTest() {
		/*cas du mot vide*/
		assertEquals(0,mot1.indiceMotifAutomate(motvide));
		/*cas normal*/
		assertEquals(0,mot3.indiceMotifAutomate(mot4));
	}

	@Test
	public void algoKMPTest() {
		/*cas du mot vide*/
		assertEquals(0,mot1.indiceMotifKMP(motvide));
		/*cas du motif plus petit que le mot a comparer*/
		assertEquals(-1,mot4.indiceMotifKMP(mot3));
		/*cas normaux*/
		assertEquals(0,mot3.indiceMotifKMP(mot4));
		assertEquals(3,mot1.indiceMotifKMP(mot2));
		
	}


  // ---Pour permettre l'exécution des test----------------------
public static junit.framework.Test suite(){
	return new junit.framework.JUnit4TestAdapter(MotTest.class);
}


}

